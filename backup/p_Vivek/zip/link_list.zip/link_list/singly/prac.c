#include "list.h"

node *reverse(node *head)
{
  node *t1, *t2;

  t1 = head;
  
  while (t1->next)
    {
      t2 = t1->next;
      t1->next = t2->next;
      t2->next = head;
      head = t2;      
    }
  return head;
}

node* rev(node* head)
{
  node *list = head;

  if (head->next)
    {
      list = rev(head->next);    
      head->next->next = head;
      head->next = NULL;
    }
  return list;
}

node *clone_list(node* head)
{
  node *tmp = NULL;
  node *clone_head = NULL;
  node *clone_tail = NULL;

  tmp = head;
  while(tmp)
    {   
      node *alt = alloc_node(tmp->data);
      if(tmp == head)
	{
	  clone_head = alt;
	  clone_tail = alt;
	}
      else
	{
	  clone_tail->next = alt;
	  clone_tail = alt;
	}
      
      tmp = tmp->next;
    }
  return clone_head;
}

int main()
{
  int list_data[] = {1, 4, 5, 7, 9, 3, 19, 15, 24, 30, 11, 18, 20};
  int size = sizeof(list_data)/sizeof(int);
  node* head = create_list(list_data, size);
  node* tmp = NULL;
  printf("\t\t *** Original List ***\n");
  print_list(head);

  node* clone = clone_list(head);
  printf("\n\t\t *** Clone List ***\n");
  print_list(clone);
  printf("\n");
  return 0;
}
