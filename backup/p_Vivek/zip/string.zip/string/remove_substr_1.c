#include "header.h"

/****************************************************************

http://www.careercup.com/question?id=5944460617711616

 You are given a string S and a set of n substrings. You are 
supposed to remove every instance of those n substrings from 
S so that S is of the minimum length and output this minimum length.
Eg:
S- ccdaabcdbb
n=2 - substrings-- ab, cd
Output: 2
Explanation:
ccdaabcdbb -> ccdacdbb -> cabb -> cb (length=2)
Can someone help me with the algo?

 ***************************************************************/
