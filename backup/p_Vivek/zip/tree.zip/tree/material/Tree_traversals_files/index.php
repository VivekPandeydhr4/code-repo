if ( mw.config.get('wgPageName') === 'Wikipedia:Dispute_resolution_noticeboard/request' ) {
    importScript( 'MediaWiki:Gadget-DRN-wizard.js' );
}