#ifndef HEADER_H_
#define HEADER_H_
/*************************************************************/

#include <stdio.h>
#include <stdlib.h>

typedef struct NODE
{
  int data;
  struct NODE *next;
}node;

node* alloc_node(int num)
{
  node* newnode = (node*)malloc(sizeof(node));
  newnode->data = num;
  newnode->next = NULL;
  return newnode;
}

//int list_data[] = {1, 4, 5, 7, 9, 3, 19, 15, 24, 30, 11, 18, 20};


node* add_node(node* head, int num)
{
  node* temp;
  node* newnd = NULL;

  newnd = alloc_node(num);

  if (head == NULL) return newnd;

  for(temp=head; temp->next!=NULL; temp=temp->next);

  temp->next = newnd;

  return head;
}

node* create_list(int arr[], int size)
{
  node* head = NULL;
  int i=0;

  for(i=0; i<size; i++)
    head = add_node(head, arr[i]);
  return head;
}


/************************************************************/
#endif
